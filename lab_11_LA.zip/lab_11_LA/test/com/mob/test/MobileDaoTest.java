package com.mob.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.dao.MobileDao;
import com.mob.dao.MobileDaoImpl;
import com.mob.exception.MobileException;


public class MobileDaoTest {
	static PurchaseDetailsBean purchaseBean;
	static MobileDao mobileDao;	
		@BeforeClass
		public static void initialize(){
			purchaseBean=new PurchaseDetailsBean();
			mobileDao=new MobileDaoImpl();
		}
	@Test
	public void TestAddTestDetails() throws MobileException{
		//purchaseid, cname, mailid, phoneno, purchasedate, mobileid
		purchaseBean.setcName("Kritika");
		purchaseBean.setMailId("yoyo@gmail.com");
		purchaseBean.setMobileId("1001");
		purchaseBean.setPhNumber(1234567890);
		int id=mobileDao.addPurchaseDetails(purchaseBean);
		assertTrue(id>1000);
		
	}
	
}
