package com.mob.service;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.dao.MobileDao;
import com.mob.dao.MobileDaoImpl;
import com.mob.exception.MobileException;

public class MobileServiceImpl implements MobileService {
	MobileDao mobileDao = new MobileDaoImpl();
	@Override
	public int addPurchaseDetails(PurchaseDetailsBean purchase) throws MobileException {
		int id = mobileDao.addPurchaseDetails(purchase);
		return id;
	}

}
