package com.mob.service;

import com.mob.bean.PurchaseDetailsBean;
import com.mob.exception.MobileException;

public interface MobileService {
	public int addPurchaseDetails(PurchaseDetailsBean purchase) throws MobileException;

}
