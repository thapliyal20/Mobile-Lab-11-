package com.mob.bean;

public class MobilesBean {
	private String mobileId;
	private String mobileName;
	private float mobilePrice;
	private int mobileQuant;
	
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public float getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(float mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public int getMobileQuant() {
		return mobileQuant;
	}
	public void setMobileQuant(int mobileQuant) {
		this.mobileQuant = mobileQuant;
	}
	
	
	
	
}
