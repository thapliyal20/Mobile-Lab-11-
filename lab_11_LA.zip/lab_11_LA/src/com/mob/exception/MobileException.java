package com.mob.exception;

public class MobileException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1000L;

	public MobileException( String message) {
		super(message);
		}
	

}
